# Golang

This Golang application is set up to use `fresh` in development mode through
Docker Compose, which allows for automated rebuilds on code change.
